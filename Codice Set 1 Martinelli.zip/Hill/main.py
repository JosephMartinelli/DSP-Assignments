#Libreria che utilizzo per avere una lista di lettere dell'alfabeto
import random
import string
#Libreria per la gestione delle matrici e relative operazioni
import time
#Per la gestione dei calcoli delle matrici
import sympy as sy


#Lista contente le lettere dell'alfabeto
alphabet = list(string.ascii_lowercase)

#Si utilizza l'algoritmo Euclideo per determinare il MCD
def GCD(x,y):
    while (y):
        x, y = y, x % y
    return x


def det(matrix):
    return sy.matrices.det(matrix)

def preprocessText(lines):
    clean_text = ""
    if len(lines) == 0:
        raise ValueError("Il file è vuoto")
    for line in lines:
        clean_text += line.replace(" ","").replace("\n","").replace("--","").replace(".","").replace(",","").replace(";","").replace("-","").casefold()
    return clean_text


def generateKey():
    matrix = sy.Matrix([[6,24,1],[13,16,10],[20,17,15]])
    if GCD(det(matrix),26) != 1:
        raise ValueError("Chiave non invertibile!")
    return matrix

def divideTextInBlocks(text,m):
    print("####### Inizio divisione testo ######")
    cleaned_text = preprocessText(text)
    mblock_vect = []
    text_len = len(cleaned_text)
    print("Lunghezza testo: ", text_len)
    num_blocks = int(text_len / m)
    print("Numero blocchi: ", num_blocks)
    letters_remaining = text_len - num_blocks * m
    print("Lettere rimanenti: ", letters_remaining)
    if letters_remaining > 0:
        letters_to_add = m - letters_remaining
        print("Lettere da aggiungere: " + str(letters_to_add) + "\nAggiunta di caratteri speciali (x)")
        for i in range(letters_to_add):
            cleaned_text += "x"

    print("####### Fine divisione testo ######")
    print("Dimensione singolo blocco: ", m)
    print("Numero blocchi trovati: ", num_blocks)
    print("####################################")

    i = 0
    while i < (len(cleaned_text)):
        array = sy.Matrix([alphabet.index(cleaned_text[i]),alphabet.index(cleaned_text[i+1]),alphabet.index(cleaned_text[i+2])])
        mblock_vect.append(array)
        i += 3

    return mblock_vect



def encryption(mblock_vect,key,m):
    #L'encryption consiste in una serie di m equazioni lineari tra plaintext e chiave mod 26
    #Poichè la chiave è una matrice m x m per poter eseguire il prodotto tra plaintext e chiave
    #dobbiamo dividerci il testo in vettori m x 1 per poter effettuare la moltiplicazione
    #(Condizione delle matrici)
    #La divisione del testo è stata fatta in precedenza

    print("##### Inizio cifratura #####")
    print("Blocchi da cifrare: ",len(mblock_vect))
    #vettore contenente tutte le lettere cifrate ciphertext
    cipher = []
    for block_vect in mblock_vect:
        cipher.append( key * block_vect % 26 )
    print("##### Fine cifratura #####")
    return cipher



def writeOnFile(collection,path):
    file = open(path,"w")
    for vect in collection:
        for letter in vect:
            file.write(alphabet[letter])
    print("##### Scrittura su file: " + str(path) + " #####")
    file.close()


def findInverseKeyMatrix(key):
    key = sy.Matrix(key)
    return key.inv_mod(26)

def isIdentity(inverse_key,key,m):
    identity = sy.Identity(m).as_explicit()
    return identity == (inverse_key * key % 26)

def decryption(cyphertext,key,m):
    #Ci calcoliamo l'inversa della chiave mod 26
    #Questa sicuramente esiste poichè è stato fatto il controllo nel metodo generateKey(m)
    result_vect = []
    #Inversa chiave
    inverse_key = findInverseKeyMatrix(key)

    #Controlliamo che la chiave inversa sia stata calcolata correttamente
    if not isIdentity(inverse_key,key,m):
        raise ArithmeticError("Chiave * Chiave**(-1) % 26 != Identità !")

    print("##### Inizio decifratura #####")
    for cipher in ciphertext:
        cipher_matrix = sy.Matrix(cipher)
        result_vect.append(inverse_key * cipher_matrix % 26)
    print("##### Fine decifratura #####")
    return result_vect



def createRandomMcoppie(m,key):
    #Ci selezioniamo M blocchi di testo random
    print("##### Scelta di m blocchi random #####")
    text = preprocessText(open("text.txt","r").readlines())
    blocks = divideTextInBlocks(text,m)
    #Scelta random di m blocchi unici
    chosen_blocks_index = random.sample(range(len(blocks)),m)
    chosen_blocks = []
    for block in chosen_blocks_index:
        chosen_blocks.append(blocks[block])

    #La chiave non è conosciuta all'attaccante
    #Però l'attaccante conosce il blocco cifrato
    #Passiamo la chiave ma l'attaccante non la conosce
    encrypted_blocks = encryption(chosen_blocks,key,m)

    return chosen_blocks,encrypted_blocks

def attackHill(size_key,key):
    #L'attacco al cifrario di Hill è di tipo known plaintext
    #Cioè l'attaccante conosce parti di plaintext P e la loro corrispondente cifratura
    #Si costruisce un insieme di coppie di tipo <P,E[P]>
    print("**************** @@@@@@@@@@@@@@ Inizio attacco @@@@@@@@@@@@@@ ****************")

    t0 = time.process_time()
    cicles = 0
    coppie = []
    while True:
        p_star = sy.Matrix()
        plaintext_bloc,encrypted_block = createRandomMcoppie(size_key,key)
        #Verifichiamo se la matrice di plaintext è invertibile
        #Altrimenti le scegliamo ancora
        for i in range(0,3):
            p_star = p_star.row_join(plaintext_bloc[i])
        if GCD(det(p_star),26) == 1:
            break
        cicles += 1
        coppie.clear()

    print("**************** @@@@@@@@@@@@@@ ATTACCO RIUSCITO @@@@@@@@@@@@@@ ****************")
    print("Tempo impiegato:  " + str(time.process_time() - t0) + "ms \nCicli necessari: " + str(cicles))
    c_star = sy.Matrix()
    for i in range(0, 3):
        c_star = c_star.row_join(encrypted_block[i])

    found_key = c_star * p_star.inv_mod(26) % 26
    print("Chiave originaria:\n",key)
    print("Chiave trovata:\n",found_key)





if __name__ == "__main__":
    plainTextLoc = "text.txt"
    cipher = "ciphertext.txt"
    decri = "decripted.txt"

    m = 3
    key = generateKey()
    plaintext = open(plainTextLoc, "r")
    plaintext = plaintext.readlines()

    #Ci dividiamo il testo in blocchi
    mblock_vect = divideTextInBlocks(plaintext,m)

    ciphertext = encryption(mblock_vect,key,m)

    writeOnFile(ciphertext,cipher)

    decripted_plaintext = decryption(ciphertext,key,m)

    writeOnFile(decripted_plaintext,decri)

    #La chiave viene passata ma l'attaccante non la conosce
    attackHill(m,key)



