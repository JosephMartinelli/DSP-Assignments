import math
import string
import re
import time as t
import matplotlib.pyplot as plt
from datetime import datetime



alphabet = list(string.ascii_lowercase)

t0 = 0

def start_time():
    global t0
    print("** Starting time count **")
    t0 = t.process_time()

def stop_time():
    print("** Elapsed time is: " + str(t.process_time() - t0) + "ms **")



def create_histogram(lines):
    text = preprocessText(lines)
    letter_dic = {}

    for letter in alphabet:
        letter_dic.update({letter: text.count(letter) / len(text)})

    plt.bar(letter_dic.keys(),letter_dic.values(),color='g')
    plt.savefig("Istogramma delle lettere dell'alfabeto.png")
    plt.show()
    plt.clf()
    plt.cla()
    plt.close()



def preprocessText(lines):
    clean_text = lines.lower()
    clean_text = "".join(re.split("[^a-z]*",clean_text))
    return clean_text




def distributionMblocks(m,lines):
    print("##### Conta dei blocchi da dividere il testo #####")
    start_time()
    text = preprocessText(lines)
    text_len = len(text)
    print("Lunghezza testo: ",text_len)
    num_blocks = int(text_len / m)
    print("Numero " + str(m) +"-grammi possibili: ",num_blocks)
    letters_remaining = text_len - num_blocks * m
    print("Lettere rimanenti: ",letters_remaining)
    if letters_remaining > 0:
        letters_to_add = m - letters_remaining
        print("Lettere da aggiungere: ",letters_to_add)
        for i in range(letters_to_add):
            text += "."
    print("Nuova lunghezza del testo: ",len(text))
    new_num_blocks = int(len(text) / m)

    print("Digrammi totali finali: ",new_num_blocks)

    #Creazione di un dizionario per ogni blocco del testo
    print("##### Costruzione blocchi #####")
    block_dic = {}
    for i in range(0,len(text),m):
            block_dic.update({text[i:i+m]: text.count(text[i:i+m]) / new_num_blocks})

    print(str(m)+"-grammi unici trovati: " , len(block_dic.keys()))
    print("##### Fine Costruzione blocchi #####")

    start_time()
    #Creiamo l'istogramma

    plt.bar(block_dic.keys(),block_dic.values(),color="r")
    if m > 1:
        #Rimozione dei label degli elementi delle ascisse poichè sono tanti
        # X-axis tick label
        plt.xticks(color='w')
        plt.tick_params(bottom=False)

    plt.xlabel('Blocchi')
    plt.ylabel('Frequenza del blocco')
    plt.title('Istogramma della frequenza dei ' + str(len(block_dic.keys())) + " unici con m = " + str(m))
    plt.savefig("Istogramma con m = " + str(m) + ".png")
    plt.show()
    plt.clf()
    plt.cla()
    plt.close()

    #Li ritorniamo visto che dopo dobbiamo calcolare entropia ed coincidenza e preferisco farlo in un'altra funzione
    stop_time()
    return block_dic,new_num_blocks,text


def coincidenzaEntropiaMblocchi(block_dic,block_num,text,m):
    print("##### Calcolo della coincidenza ed entropia #####")
    #L'indice di coincidenza di Ic(x) dove x è una sequenza di blocchi è definita come la probabilità che due blocchi estratti da x
    #,senza rimpiazzo, siano uguali. Quindi l'indice è calcolato come la sommatoria per ogni blocco i del quoziente
    # fi * (fi - 1) / n ( n - 1) dove fi indica il numero di occorrenze di quel blocco nel testo ed n indica il numero dei blocchi
    coincidenza = 0
    for key in block_dic.keys():
         fi = text.count(key)
         coincidenza += ((fi - 1) * fi) / ((block_num - 1) * block_num)

    print("Coincidenza degli m-blocchi: ",coincidenza)

    entropy = 0
    for key in block_dic.keys():
        entropy += block_dic.get(key) * math.log2(block_dic.get(key))

    entropy = -entropy
    print("Entropy: ",entropy)

    print("##### Saving results in .csv file #####")
    dump_file = open("results.txt","a")
    dump_file.write("##### Con m: " + str(m) + " blocchi #####\n")
    dump_file.write("Data esecuzione: " +str(datetime.now()) + "\n")
    dump_file.write("Numero dei blocchi totali: " +str(block_num) + "\n")
    dump_file.write("Indice di coincidenza: " + str(coincidenza) + "\n")
    dump_file.write("Entropia: " + str(entropy) + "\n")
    dump_file.write("#############################\n\n")


if __name__ == "__main__":
    input_fileName = "text.txt"
    file = open(input_fileName,"r")

    #Contenuto del file
    lines = file.read()

    #1. Istogramma della frequenza delle 26 lettere
    create_histogram(lines)

    response = True
    while response:
        while True:
            print("Indicare lunghezza degli m-grammi da studiare (lunghezza deve essere >= 1)")
            lenght = 0
            try:
                lenght = int(input())
            except:
                print("La lunghezza deve essere un intero")
            if lenght >= 1:
                break

        #2. Dato m ≥ 1 in input, distribuzione empirica degli m-grammi (blocchi di m lettere);
        block_dic,block_num,text = distributionMblocks(lenght,lines)

        #3. Dato m ≥ 1, indice di coincidenza ed entropia della distribuzione degli m-grammi.
        coincidenzaEntropiaMblocchi(block_dic,block_num,text,lenght)

        print("Provare con un m differete [Y/N]?")
        response = str(input()).casefold()
        if response == "n":
            response = False

    file.close()