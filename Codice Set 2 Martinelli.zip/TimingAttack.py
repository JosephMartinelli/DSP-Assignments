import random
from TimingAttackModule import *


def attack(ta,N,k):
    #Sappiamo che l'esponente segreto d ha il bit più a sinistra uguale a 1
    #Quindi settiamo anche il vettore d' con il bit più a sinistra uguale a 1
    d_primo = [1]
    #k Rappresenta il numero di bit dell'esponente d che è conosciuto
    #Quello che sostazialmente facciamo è la cosa seguente
    #@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    # Prendiamo d --> [1,x] dove x è un bit uguale a 1 o 0
    # Preso il tempo di esecuzione dell'algoritmo di esponenziazione modulare con base c conosciuta e random
    # Calcoliamo la differenza tra il tempo di esecuzione dell'algoritmo di esponenziazione modulare con x = 0 e x = 1
    # Calcoliamo la varianza
    # Il bit che ci da la varianza minore lo aggiungiamo a d_primo in quanto la varianza minore indica un tempo di esecuzione
    # più simile rispetto al d originale
    #@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    while len(d_primo) < k:
        #Contengono i tempi di esecuzione con bit = 0 e bit = 1
        t0 = []
        t1 = []
        #Quante volte dobbiamo calcolare la varianza per prendere una decisione? --> Tanto quanto N
        for i in range(N):
            c = random.randint(0, 1000000000000000000)
            time_victim = ta.victimdevice(c)
            temp_vect = d_primo.copy()
            temp_vect.append(1)
            #Calcolo del tempo dell'algoritmo di esponenziazione con bit = 1
            time_attacker = ta.attackerdevice(c, temp_vect)
            t1.append(time_victim - time_attacker)
            temp_vect = d_primo.copy()
            temp_vect.append(0)
            #Calcolo del tempo dell'algoritmo di esponenziazione con bit = 0
            time_attacker = ta.attackerdevice(c, temp_vect)
            t0.append(time_victim - time_attacker)

        # Calcolo delle due varianze dei due vettori contenenti le differenze
        var1 = varianza(N, t1)
        var0 = varianza(N, t0)
        # Confronto delle due varianze ottenute in modo da decidere quale è il bit da inserire in d'
        if var1 < var0:
            d_primo.append(1)
        else:
            d_primo.append(0)
    return d_primo


# Metodo che calcola la varianza secondo la formula Set 2 esercizio 2.2
def varianza(N,t):
    somm1 = 0
    somm2 = 0
    for j in range(N):
        somm1 = t[j] ** 2 + somm1
        somm2 = t[j] + somm2
    somm2 = (1 / N * somm2) ** 2
    var = 1 / N * somm1 - somm2
    return var


if __name__ == '__main__':
    ta = TimingAttack()
    d_len = 64 #Noto
    result_of_attack = attack(ta, 3000,d_len)
    ta.test(result_of_attack)