import random
import time



def esponenziazioneVeloce(base,esponente,modulo):
    #Fase di espansione in base due dell'esponente
    n = list(format(esponente,"b"))
    #Vettore risultante mi va a dire quante volte posso elevare al quadrato, se si trova uno allora devo moltiplicare
    #Per la base
    #Variabile d dei prodotti parziali
    d = 1
    #Variabile contatrice del ciclo
    c = 0
    for i in range(0, len(n)):
        d = (d * d) % modulo
        c = c * 2
        if int(n[i]) == 1:
            d = (d * base) % modulo
            c = c + 1
    return d

def euclideEsteso(a, b):
    #Caso base
    if a == 0:
        return b, 0, 1
    gcd, x1, y1 = euclideEsteso(b % a, a)
    #Stiamo risalendo la sequenza di resti non negativi ottenuti applicando ripetutamente il teorema della divisione
    #Sostanzialmente ci stiamo calcolando il valore del coefficiente x come
    #x = rm-2 - qm-1 * rm-1 dove rm-2 è il resto di due passi precedenti e rappresentato dal coefficiente di a
    # rm-1 è il resto precedentemente calcolato da b % a
    # qm-1 è il coefficiente che ci calcoliamo come b // a
    x = y1 - (b // a) * x1
    y = x1
    return gcd, x, y


def testMillerRabin(n):
    #Il test di Rabin vale vero se e solo se 0 < x < n e posto n - 1 = 2**r * m con m dispari
    #Scriviamo n - 1 = 2 ** r * m con m dispari
    #Ricerca di m e di s
    m = n - 1
    r = 0
    while m % 2 == 0:
        m //= 2
        r += 1

    # Scelta di un numero casuale x tc: 1 < x < n - 1
    a = random.randint(1, n - 1)

    #Prima iterazione
    x = esponenziazioneVeloce(a,m,n)
    if x == 1:
        return False
    for i in range(r):
        val = esponenziazioneVeloce(x,2,n)
        if val == (-1 % n):
            return False
        x = val

    gcd,_,_ = euclideEsteso(x,n)

    return True and gcd == 1



def generaNumeroPrimo():
    t0 = time.process_time()
    flag = False
    while not flag:
        flag = True
        #Creazione di un vettore da 400 bits casuale (121 cifre decimali)
        bigVect = random.getrandbits(400)
        #Poniamo il bit meno significativo a 1 così il numero è dispari
        bigVect |= 1
        #Poniamo il bit più significativo a 1 così il numero è nell'ordine di 2**k
        bigVect |= 1 << 400
        #Applicazione test di primalità
        #Il numero di volte (20) è stato scelto arbitrariamente
        for i in range(20):
            if testMillerRabin(bigVect):
                flag = False
                break


    print("Tempo impiegato per la generazione di un numero primo: " + str(time.process_time() - t0))
    return bigVect




if __name__ == "__main__":
    #Generazione di un numero grande
    bigN1 = random.getrandbits(400)
    bigN2 = random.getrandbits(400)

    #1. Algoritmo di Euclide esteso.
    gcd,x,y = euclideEsteso(bigN1,bigN2)
    # #Testing con valori noti
    # gcd,x,y = euclideEsteso(17,60)


    #2. Algoritmo di esponenziazione modulare veloce.
    #Sono stati inseriti valori noti per verificare il funzionamento
    #Più avanti nel codice la funzione è stata usata anche con interi aventi almeno 121 cifre
    esponenziazioneVeloce(3,11,10)

    #3. Test di Miller-Rabin
    #Anche qui valore noto di testing
    if testMillerRabin(104717):
        print("Composto")
    else:
        print("Probabilmente primo")

    #4. Algoritmo per la generazione di numeri primi.
    num = generaNumeroPrimo()
    e = 11
    while True:
        #5. Schema RSA, con e senza ottimizzazione CRT.
        #5.1 Schema RSA senza ottimizzazione
        #Generiamo p e q numeri primi,segreti,distinti e molto grandi
        p = generaNumeroPrimo()
        q = generaNumeroPrimo()
        #Modulo pubblico
        n = p * q
        #Generazione della chiave privata
        phi_n = (p - 1) * (q - 1)
        gcd,d,y = euclideEsteso(e,phi_n)
        # Caso in cui d è negativo
        if d < 0:
            d += phi_n
        #Condizione necessaria per d
        if euclideEsteso(d,phi_n)[0] == 1:
            break

    print("@@@@@@@@@@ CHIAVE PUBBLICA @@@@@@@@@@")
    print(e,n)
    print("@@@@@@@@@@ CHIAVE PRIVATA @@@@@@@@@@")
    print(d,n)


    #Encryption e decryption sono la stessa operazione di esponenziazione modulo n
    #Usiamo quindi la funzione di esponenziazione veloce e a seconda dei parametri è una encryption o meno
    print("##### Encryption #####")
    ciphers = []
    for i in range(200):
        #Generiamo 200 messaggi casuali
        val = random.getrandbits(200)
        ciphers.append(esponenziazioneVeloce(val,e,n))
    print("##### Fine encryption #####")
    print("##### Decryption #####")
    decryption_stime = time.process_time()
    decrypted = []
    for c in ciphers:
        decrypted.append(esponenziazioneVeloce(c,d,n))
    decryption_etime = time.process_time()

    #2 5.2  RSA con CRT
    #RSA sfrutta il teorema cinese del resto per accorciare la bit size dell'esponente d nascondendolo nel sistema
    #di equazioni modulari congruenti per velocizzare l'operazione di decryption.
    #I valori e,phi_n,n,p,q sono gli stessi ciò che cambia è la funzione di decryption
    crt_decryption_stime = time.process_time()
    #Questi valori vanno precomputati
    gcd, inverse_q, inverse_p = euclideEsteso(q, p)
    for c in ciphers:
        sp = esponenziazioneVeloce(c,d,p)
        sp2 = esponenziazioneVeloce(c,d,q)
        #Formula teorema cinese del resto
        final = (sp * q * inverse_q + sp2 * p * inverse_p) % (p * q)
    crt_decryption_etime = time.process_time()
    print("##### Final report #####")
    print("Tempo di decryption RSA normale: " ,str(decryption_etime) + " - "
          + str(decryption_stime) + " = ",str(decryption_etime - decryption_stime))
    print("Tempo di decryption RSA con CRT: ", str(crt_decryption_etime) + " - "
          + str(crt_decryption_stime) + " = ", str(crt_decryption_etime - crt_decryption_stime))
    print("###########################")






