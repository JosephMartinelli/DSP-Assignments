import json
import re
from Codici.Set_3.Huffman.huffman import buildTree


def getFreqDataFromFile(file):
    with open(file, "r") as f:
        return json.load(f)

def normalizeFreqData(data,differentFormat = False):
    sum = 0
    if not differentFormat:
        for elem in data:
            sum += elem[1]
        for elem in data:
            elem[1] /= sum
        return data
    #Questo else serve a gestire il formato diverso in cui il file json freqSingoleLettere contiene i dati
    else:
        for val in data.values():
            sum += val
        for key in data.keys():
            data[key] /= sum
        return data

def getLunghezzaMediaCodici(code,prob):
    valore_atteso = 0
    for key in code.keys():
        valore_atteso += len(code.get(key)) * prob.get(key)
    return valore_atteso

def buildProbabilityC2(freq_letters,other_dictionary):
    result_dictionary = {}
    for key in other_dictionary.keys():
        result_dictionary.update({ key: freq_letters[key[0]] * freq_letters[key[1]]})
    return result_dictionary

def preprocessText(lines):
    clean_text = lines.lower()
    clean_text = "".join(re.split("[^a-z]*",clean_text))
    return clean_text

def encodeText(text,code):
    print("Lunghezza originale testo in bits UTF-7:  ", len(text) * 7 , " oppure UTF-8" ,len(text) * 8)
    result_text = ""
    #Divido il testo in digrammi
    for i in range(0,len(text) - 2, 2):
        if code.get(text[i:i+2]) is not None:
            result_text += code.get(text[i:i+2])
    print("Lunghezza con compressione in bits: ",len(result_text))
    return len(result_text)

if __name__ == "__main__":
    #Le frequenze per file1 sono state prese da https://gist.github.com/lydell/c439049abac2c9226e53
    #Il file2 contiene le frequenze delle singole lettere della lingua inglese (da Wikipedia)
    file1 = "freqDigrammi.json"
    file2 = "freqSingoleLettere.json"
    letter_dependence = getFreqDataFromFile(file1)
    letter_independence = getFreqDataFromFile(file2)
    freq_letter_C1 = normalizeFreqData(letter_dependence)
    freq_letter_C2 = normalizeFreqData(letter_independence,True)
    #La costruzione del dizionario è necessaria in modo tale da poter riusare il codice scritto precedentemente
    prob_letters_C1 = {x[0]:x[1] for x in freq_letter_C1}
    print(prob_letters_C1)
    #Ci dobbiamo costruire C2 sulla distribuzione prodotto delle due lettere
    #Quindi prendiamo un digramma e moltiplichiamo la distribuzione delle due lettere
    prob_letters_C2 = buildProbabilityC2(freq_letter_C2,prob_letters_C1)

    code_C1 = buildTree(prob_letters_C1.keys(),prob_letters_C1.copy(),False)
    code_C2 = buildTree(prob_letters_C2.keys(),prob_letters_C2.copy(),False)

    lunghezzaMediaC1 = getLunghezzaMediaCodici(code_C1,prob_letters_C1)
    lunghezzaMediaC2 = getLunghezzaMediaCodici(code_C2,prob_letters_C2)
    delta = lunghezzaMediaC2 - lunghezzaMediaC1

    print("Lunghezza media codice C1: ",lunghezzaMediaC1)
    print("Lunghezza media codice C2: ",lunghezzaMediaC2)
    print("Delta: ",delta)

    #Applichiamo i codici ad un testo e verifichiamo la linking identity
    file_text = open("text.txt","r")
    text = preprocessText(file_text.read())

    encoded_text_C1 = encodeText(text,code_C1)
    encoded_text_C2 = encodeText(text, code_C2)
    encoded_delta = encoded_text_C2 - encoded_text_C1
    print("Encoded delta: ",encoded_delta)



