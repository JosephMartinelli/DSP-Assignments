import ast
import string



class Node:
    def __init__(self,letter,val = 0,rightNode = None, leftNode = None):
        self.value = val
        self.letter = letter
        self.right = rightNode
        self.left = leftNode

    def __eq__(self, other):
        if other is None:
            return None
        if other is not Node:
            other = Node(other)
            return self.letter == other.letter

def buildCode(node,current_trei,dic):
    if node.right is None:
        dic.update({node.letter:current_trei})
        return dic
    right_dic = buildCode(node.right, current_trei + str(1),dic)
    left_dic = buildCode(node.left, current_trei + str(0),right_dic)
    return left_dic

#Orribile complessità: Lo so
#Si intende passare un codice in forma di dizionario
def isPrefixFree(code):
    for val in code.values():
        for elem in code.values():
            if str(val) != str(elem):
                if str(elem).startswith(str(val)):
                    return False
    return True


def findMinLetterBasedOnProb(letters,probs):
    min_prob = min(probs.values())
    for node in letters:
        if node.value == min_prob:
            letters.remove(node)
            probs.pop(node.letter)
            return node,min_prob,letters,probs


def convert(x):
    return Node(x)

def buildTree(letters,probs,prints=True):
    #Convertiamo ogni lettera in un potenziale nodo
    letters = list(map(convert,letters))
    for letter in letters:
        letter.value = probs[letter.letter]
    while len(letters) != 1:
        first_node,first_prob,letters,probs = findMinLetterBasedOnProb(letters,probs)
        second_node,second_prob,letters,probs = findMinLetterBasedOnProb(letters,probs)
        root = Node( first_node.letter + second_node.letter,first_node.value + second_node.value,rightNode=second_node,leftNode=first_node)
        if prints:
            print("Node: ",root.letter + " RIGHT: ",root.right.letter + " LEFT: ", root.left.letter)
        letters.append(root)
        probs.update({root.letter:root.value})

    result_dic = buildCode(letters[0],"",{})
    return result_dic


def normalizeFreq(freq):
    sum = 0
    for val in freq.values():
        sum += val
    for key in freq.keys():
        freq.update({key:freq.get(key) / sum})
    return freq

def decode(input_string):
    decoded_string = ""
    j = 0
    for i in range(len(input_string)):
        key = input_string[j:i+1]
        x = input_code.get(key)
        if x is not None:
            decoded_string += x
            j = i + 1
    return decoded_string

if __name__ == "__main__":
    alphabet = list(string.ascii_lowercase)
    #Da wikipedia
    freq = {
            "a": 8.2,
            "b":1.5,
            "c":2.7,
            "d":4.7,
            "e":13,
            "f":2.2,
            "g":2,
            "h":6.2,
            "i":6.9,
            "j":0.16,
            "k":0.81,
            "l":4.0,
            "m":2.7,
            "n":6.7,
            "o":7.8,
            "p":1.9,
            "q":0.11,
            "r":5.9,
            "s":6.2,
            "t":9.6,
            "u":2.7,
            "v":0.97,
            "w":2.4,
            "x":0.15,
            "y":2,
            "z":0.078}

    freq = normalizeFreq(freq)
    print(freq)

    HuffmanCode = buildTree(alphabet,freq)

    if not isPrefixFree(HuffmanCode):
        raise ArithmeticError("Il codice non è prefix-free")

    print(HuffmanCode)

    print("Inserire dizionario di un codice o scrivere TEST per utilizzare Huffman e testare semplicemente la decodifica")
    input_code = input()
    if input_code.lower() != "test":
        #Convertiamo la stringa dizionario in un dizionario vero e proprio
        input_code = ast.literal_eval(input_code)
        #Verifichiamo che il codice inserito sia prefix-free
        if not isPrefixFree(input_code):
            raise ArithmeticError("Il codice inserito non è prefix-free")
    else:
        # Per testing gli passiamo il codice di prima ma invertito
        #Cioè per decodificare le chiavi non saranno le lettere ma le codifiche di quelle lettere
        input_code = {v: k for k, v in HuffmanCode.items()}

    print("Inserire stringa da decodificare")
    input_string = input()

    decoded_string = decode(input_string)
    print(decoded_string)




